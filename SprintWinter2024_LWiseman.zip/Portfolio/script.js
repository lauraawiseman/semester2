// Function to change the project based on button click
function changeProject(projectNumber) {
  // Hide all the project slides first
  const slides = document.querySelectorAll('.project-slide');
  slides.forEach((slide) => {
    slide.style.display = 'none'; // Hides the slide
  });

  // Show the selected project slide
  const selectedSlide = document.getElementById('slide' + projectNumber);
  if (selectedSlide) {
    selectedSlide.style.display = 'block'; // Display the selected project
  }
}

// Display the first project by default when the page loads
window.onload = function () {
  changeProject(1);
};
